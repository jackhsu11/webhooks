/*
  $nvm install 20.10.0
  $nvm use 20.10.0
*/

const express = require('express');
const bodyParser = require('body-parser');
const app = express();
const port = 3000;

// Middleware to parse incoming request data as JSON
app.use(bodyParser.urlencoded({ extended: true })); // fixed deprecation warning with extended : true
app.use(bodyParser.json()); // allows req.body.accountId to be read

// Route to handle GET requests at the root URL
app.get("/", (req, res) => {
  if (fetchedData) {
    // Render the fetched data on the page
    res.send(`
      <h1>Fetched Account Data</h1>
      <pre>${JSON.stringify(fetchedData, null, 2)}</pre>
    `);
  } else {
    res.send("Webhook server is up and running! No data fetched yet.");
  }
});

// Function to handle fetching account data
const fetchAccountData = async (accountId) => {
  const url = 'https://api-sandboxdash.norcapsecurities.com/tapiv3/index.php/v3/getAccount';
  const options = {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({
      clientID: '',
      developerAPIKey: '',
      accountId: accountId
    })
  };

  const response = await fetch(url, options);
  return response.json();
}

// Route to handle POST requests at the root URL
app.post("/", async (req, res) => {
  console.log('POST request received at /');
  const accountId = req.body.accountId;

  // Log and validate the accountId
  console.log('Received accountId:', accountId);
  if (!accountId) {
    return res.status(400).json({ message: 'Missing accountId in request' });
  }

  try {
    fetchedData = await fetchAccountData(accountId);
    
    // Log the fetched information
    console.log('Fetched Information:', fetchedData);

    // Redirect to the root URL to display the fetched data
    res.redirect("/");
  } catch (err) {
    console.error('Error:', err);

    // Send an error response
    res.status(500).json({ message: 'Error fetching account data', error: err.message });
  }
});

app.listen(port, () => {
  console.log(`Webhook server is running on port ${port}`);
});