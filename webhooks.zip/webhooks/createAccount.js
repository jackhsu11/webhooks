/*
  Another example
*/

const express = require("express");
const bodyParser = require("body-parser");
const app = express();
const port = 3000;

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

app.get("/", (req, res) => {
  
  res.send("Webhook server is up and running! No data fetched yet.");
  
});

app.post("/", (req, res) => {
  const fetch = require('node-fetch');

  const url = 'https://api-sandboxdash.norcapsecurities.com/tapiv3/index.php/v3/createAccount';
  const options = {
    method: 'PUT',
    headers: {'content-type': 'application/json'},
    body: JSON.stringify({
      clientID: req.body.clientID,
      developerAPIKey: req.body.developerAPIKey,
      accountRegistration: 'string',
      type: 'string',
      entityType: 'string',
      domesticYN: 'string',
      streetAddress1: 'string',
      streetAddress2: 'string',
      city: 'string',
      state: 'string',
      zip: 'string',
      country: 'string',
      email: 'string',
      phone: 0,
      taxID: 0,
      KYCstatus: 'string',
      AMLstatus: 'string',
      AMLdate: '2024-09-02',
      suitabilityScore: 0,
      suitabilityDate: '2024-09-02',
      suitabilityApprover: 'string',
      AccreditedStatus: 'string',
      Allow: 'string',
      AIdate: '2024-09-02',
      '506cLimit': 0,
      accountTotalLimit: 0,
      singleInvestmentLimit: 0,
      associatedAC: 'string',
      syndicate: 'string',
      tags: 'string',
      notes: 'string',
      approvalStatus: 'string',
      approvalPrincipal: 'string',
      approvalLastReview: '2024-09-02',
      field1: 'string',
      field2: 'string',
      field3: 'string'
    })
};

  fetch(url, options)
    .then(res => res.json())
    .then(json => console.log(json))
    .catch(err => console.error('error:' + err));
});

app.listen(port, () => {
  console.log(`Webhook server is running on port ${port}`);
});



